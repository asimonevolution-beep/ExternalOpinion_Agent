# External Opinion v12 - AI Orchestrated System
Progetto del Geom. Simone Azzali.

## Struttura
- `index.html`: Interfaccia decisionale.
- `riskEngine.js`: Motore deterministico v10.1 (Blindato).
- `orchestrator.js`: Orchestratore multi-modello ready.

## Note
Pronto per deploy su Vercel o Cloudflare Pages.